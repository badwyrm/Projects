#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
	int i;
	int empId[7] = { 5658845,4520125,7895122,8777541,8451277,1302850,7580489 };
		double rate, hour, wages[7];

	for (i = 0; i <= 6; i++)
	{
		cout << "Employee number: " << empId[i] << endl;

		cout << "\nEnter employee's hours: ";
		cin >> hour;
		while (hour < 0)
		{
			cout << "Invalid Input. Hours cannot be negative." << endl;
			cout << "Enter employee's hours: ";
			cin >> hour;
		}
		cout << "Enter employee's pay rate: ";
		cin >> rate;
		while (rate < 15)
		{
			cout << "Invalid Input. Employee's pay rate must be higher than $15." << endl;
			cout << "Enter employee's pay rate: ";
			cin >> rate;
		}
		wages[i] = hour * rate;
		cout << "\n";
	}

	for (i = 0; i <= 6; i++)
	{
		cout << "Employee number: " << empId[i] << endl;
		cout << "Employee gross wages: " << fixed << setprecision(2) << wages[i] << endl;
	}
	}