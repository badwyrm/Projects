#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	srand(time(NULL)); //seed
	int values[10][6] = { 0 }; //generate array
	int rows = 0, columns = 0, i = 0;

	for (rows = 0; rows < 10; rows++)
	{
		for (columns = 0; columns < 6; columns++)
		{
			values[rows][columns] = rand() % 10 + 1;
			cout << setfill('0') << setw(2) << values[rows][columns];
			if (columns < 5) {
				cout << " + ";
			}

			i += values[rows][columns];
		}
		cout << " = " << i << endl;
		i = 0;
	}
	cout << "---------------------------" << endl;
	for (columns = 0; columns < 6; columns++)
	{
		for (rows = 0; rows < 10; rows++)
		{
			i += values[rows][columns];
		}
		cout << i << "   ";
		i = 0;
	}
	cout << endl;
}