#include "Postman.h"

int box[NUM_BOX];
int main()
{
	closeMailbox(box);
	openMailbox(box);
	countMailbox(box);

	return 0;
}

