#include<iostream>
using namespace std;

int main() {
	short int si1, si2;
	int i1, i2;
	long int li1, li2;
	float f1, f2;
	double d1, d2;
	long double ld1, ld2;
	bool b1, b2;
	char c1, c2;

	cout << &si1 << endl;
	cout << &si2 << endl;
	cout << &i1 << endl;
	cout << &i2 << endl;
	cout << &li1 << endl;
	cout << &li2 << endl;
	cout << &f1 << endl;
	cout << &f2 << endl;
	cout << &d1 << endl;
	cout << &d2 << endl;
	cout << &ld1 << endl;
	cout << &ld2 << endl;
	cout << &b1 << endl;
	cout << &b2 << endl;
	cout << &c1 << endl;
	cout << &c2 << endl;
}